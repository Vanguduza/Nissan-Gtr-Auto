# Storefront PSP return / cancel URLs

- Date: 2026-07-24
- Lane: `@web_agent` (routes + client redirect); `@backend_agent` (edge provider wiring)
- Status: accepted (storefront slice)

## Storefront routes

| Path | Role |
|------|------|
| `/checkout/return?invoice=<uuid>` | Browser return after ContiPay / Paynow hosted checkout |
| `/checkout/cancel?invoice=<uuid>` | Cancel / abort from provider UI |

These pages **do not** mark invoices paid. Settlement stays on `contipay-webhook` / `paynow-webhook`. Copy explains pending webhook confirmation.

Absolute URLs are built from `window.location.origin` in the browser, else `NEXT_PUBLIC_SITE_URL` (default `https://nissangtrauto.co.zw`).

## Client → edge contract

`createCustomerContipayIntent` / `createCustomerPaynowIntent` in `apps/web/lib/customer-storefront.ts`:

1. Prefer `functions.invoke('contipay-initiate' | 'paynow-initiate')` with body fields:
   - `sales_invoice_id`, `method`
   - `return_url`, `cancel_url` (browser redirect only — never `result_url`)
   - `metadata` mirroring those URLs + `channel: storefront`
2. If the edge response includes a non-null `checkout_url`, the cart / order UI **redirects** the browser there.
3. Otherwise keep the intent-created message and stay on the order page.
4. RPC fallback `create_customer_*_intent` stores the same URLs in `p_metadata` when edge is unavailable.

**Webhook / settle URL:** Edge always registers `defaultWebhookUrl("contipay-webhook" | "paynow-webhook")` with the PSP. Clients must not send `result_url`; browser `return_url` / `cancel_url` are redirect-only. Paynow `poll_url` stays server-side (not returned in initiate JSON).

### Local stub `checkout_url` (secrets unset)

With `CONTIPAY_ALLOW_UNVERIFIED_LOCAL=1` / `PAYNOW_ALLOW_UNVERIFIED_LOCAL=1` and no merchant keys, initiate still creates the intent, merges redirect URLs into `p_metadata`, echoes `return_url` / `cancel_url` in the JSON response, and — when `return_url` is present — sets:

`checkout_url = {return_url}&psp=contipay|paynow&stub=1&intent_id={uuid}`

(existing `?invoice=` query preserved). Web can redirect to `/checkout/return` without real PSP keys. Settlement remains webhook-only; stub redirect does **not** mark paid. Response includes `stub: true`.

### Real secrets present

Edge calls ContiPay / Paynow APIs and returns the provider hosted `checkout_url` with `stub: false`. ContiPay redirect initiate needs `phone` (or `metadata.phone` / `metadata.cell`) on the invoke body. Without secrets and without `*_ALLOW_UNVERIFIED_LOCAL=1`, initiate returns **503** (fail closed).

Optional dedicated `return_url` column only if webhook reconciliation needs indexed lookup; metadata is enough for the storefront slice.

## Secrets (never commit values)

| Env | Where | Purpose |
|-----|--------|---------|
| `CONTIPAY_API_KEY`, `CONTIPAY_API_SECRET`, `CONTIPAY_MERCHANT_ID` | Edge Function env only | Real initiate (Basic Auth PUT acquire) |
| `CONTIPAY_WEBHOOK_HMAC_SECRET` | Edge Function env only | Webhook HMAC-SHA256 verify |
| `PAYNOW_INTEGRATION_ID`, `PAYNOW_INTEGRATION_KEY` | Edge Function env only | Real initiate + SHA512 field-hash verify |
| `CONTIPAY_ALLOW_UNVERIFIED_LOCAL=1` / `PAYNOW_ALLOW_UNVERIFIED_LOCAL=1` | Local edge only | Stub without secrets |
| `NEXT_PUBLIC_SITE_URL` | Web app | Public origin for return/cancel links — **not** a secret |

Do not put ContiPay / Paynow keys in `NEXT_PUBLIC_*`, migrations, or this doc.

## Exclusions

No ZIMRA / fiscal QR; no HTML5 QR; no client-side HMAC with merchant keys.
